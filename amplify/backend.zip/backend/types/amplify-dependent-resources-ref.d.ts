export type AmplifyDependentResourcesAttributes = {
    "function": {
        "Practice": {
            "Name": "string",
            "Arn": "string",
            "Region": "string",
            "LambdaExecutionRole": "string"
        }
    }
}